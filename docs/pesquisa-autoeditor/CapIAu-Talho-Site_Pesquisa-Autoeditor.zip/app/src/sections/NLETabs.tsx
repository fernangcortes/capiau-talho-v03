import { useState, useRef } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import CodeBlock from '../components/CodeBlock';

gsap.registerPlugin(ScrollTrigger);

const tabs = [
  { id: 'kdenlive', label: 'Kdenlive' },
  { id: 'blender', label: 'Blender' },
  { id: 'resolve', label: 'Resolve' },
  { id: 'premiere', label: 'Premiere' },
];

const nleContent: Record<string, {
  headline: string;
  body: string;
  pills: string[];
  code: string;
  links: { label: string; url: string }[];
}> = {
  kdenlive: {
    headline: 'Kdenlive — MLT XML Nativo',
    body: 'Melhor opcao open source. Acesso completo a effects, transitions, filters, keyframes, compositing e time remapping via geracao direta de MLT XML. OTIO nativo desde v25.04. O arquivo .kdenlive e um XML baseado no MLT Framework — producers (referencias de midia), playlists (tracks), tractors (composicao + transitions) e filters (effects) sao todos acessiveis.',
    pills: ['effects ✔', 'transitions ✔', 'keyframes ✔', 'speed ✔', 'compositing ✔', 'text ✔', 'nesting ✔', 'OTIO nativo ✔'],
    code: `<!-- Exemplo de MLT XML Kdenlive -->
<mlt xmlns:kdenlive="http://www.kdenlive.org/project">
  <profile frame_rate_num="24" width="1920" height="1080"/>
  <producer id="producer0" resource="entrevista_rose.mov">
    <property name="kdenlive:id">1</property>
  </producer>
  <playlist id="playlist0">
    <property name="shotcut:name">V1_ENTREVISTAS</property>
    <entry producer="producer0" in="00:00:05.000" out="00:00:10.000">
      <filter id="filter0">
        <property name="mlt_service">brightness</property>
        <property name="level">0.5</property>
      </filter>
    </entry>
    <blank length="00:00:00.250"/>
  </playlist>
  <tractor id="tractor0">
    <track hide="audio" producer="playlist0"/>
    <transition id="transition0">
      <property name="mlt_service">composite</property>
    </transition>
  </tractor>
</mlt>`,
    links: [
      { label: 'Documentacao Kdenlive', url: 'https://github.com/KDE/kdenlive/blob/master/dev-docs/fileformat.md' },
      { label: 'MLT Framework', url: 'https://www.mltframework.org/docs/' },
      { label: 'Grizzly Peak 3D OTIO', url: 'https://grizzlypeak3d.com/2025/05/04/grizzly-peak-3d-adds-native-opentimelineio-support-to-kdenlives-25-04-0-release/' },
    ],
  },
  blender: {
    headline: 'Blender VSE — Python API (bpy)',
    body: 'Melhor opcao programatica. Acesso a 100% das funcoes via bpy.ops.sequencer.* — strips, effects, transitions, fades, speed, transform, text, multicam, adjustment layers. A API Python do Blender e a mais completa e documentada para criacao programatica de timelines. Cada operacao da sequencer e exponivel via script, incluindo cut, duplicate, fade, meta_make e keyframe_insert.',
    pills: ['CROSS ✔', 'WIPE ✔', 'GLOW ✔', 'TRANSFORM ✔', 'SPEED ✔', 'TEXT ✔', 'ADJUSTMENT ✔', 'MULTICAM ✔'],
    code: `import bpy

seq = bpy.context.scene.sequence_editor

# Adicionar movie strip
bpy.ops.sequencer.movie_strip_add(
    filepath="entrevista_rose.mov",
    frame_start=1, channel=1
)

# Adicionar transition CROSS
bpy.ops.sequencer.effect_strip_add(
    type='CROSS', frame_start=120, frame_end=132
)

# Speed effect
bpy.ops.sequencer.effect_strip_add(
    type='SPEED', frame_start=1
)

# Fade in/out
bpy.ops.sequencer.fades_add(
    duration_seconds=1.0, type='IN_OUT'
)

# Keyframes
strip = seq.sequences_all["Movie.001"]
strip.blend_alpha = 0.5
strip.keyframe_insert(data_path="blend_alpha", frame=1)
strip.blend_alpha = 1.0
strip.keyframe_insert(data_path="blend_alpha", frame=50)

# Render
bpy.ops.render.render()`,
    links: [
      { label: 'Blender Python API', url: 'https://docs.blender.org/api/current/bpy.ops.sequencer.html' },
      { label: 'Blender VSE Manual', url: 'https://docs.blender.org/manual/en/latest/video_editing/' },
    ],
  },
  resolve: {
    headline: 'DaVinci Resolve — Python API (Studio)',
    body: 'Acesso parcial via API Python. Ideal para conform, color grading, delivery e render batch. Edicao fina (transitions, speed, color nodes) requer intervencao manual ou MCP servers. A API Resolve permite criar projetos, importar midia, criar timelines, adicionar markers, compound clips e configurar render jobs — mas nao suporta cortar, split, trim, transitions ou speed changes via script.',
    pills: ['import media ✔', 'create timeline ✔', 'add markers ✔', 'compound clips ✔', 'Fusion ✔', 'render ✔', 'transitions ✖', 'speed ✖'],
    code: `# DaVinci Resolve API Hierarchy
Resolve
├── GetMediaStorage() → MediaStorage
├── GetProjectManager() → ProjectManager
│   ├── CreateProject() → Project
│   └── GetCurrentProject() → Project
│       ├── GetMediaPool() → MediaPool
│       │   ├── ImportMedia() → [MediaPoolItem]
│       │   ├── CreateEmptyTimeline() → Timeline
│       │   └── AppendToTimeline() → [TimelineItem]
│       ├── GetCurrentTimeline() → Timeline
│       │   ├── AddMarker() → Bool
│       │   ├── CreateCompoundClip() → TimelineItem
│       │   └── Export() → Bool
│       ├── AddRenderJob() → str
│       └── SetRenderSettings() → Bool

# Exemplo basico
project = resolve.GetProjectManager().GetCurrentProject()
mediaPool = project.GetMediaPool()
timeline = mediaPool.CreateEmptyTimeline("DOC_Rose_v01")
mediaPool.ImportMedia(["/media/entrevista_rose.mov"])`,
    links: [
      { label: 'Resolve API Reference', url: 'https://gist.github.com/mhadifilms/2b84d469135315793220dbf2226cbe63' },
      { label: 'Wild Lion Guide', url: 'https://wildlion.media/davinci-resolve-python-scripting-the-complete-guide-to-the-api/' },
    ],
  },
  premiere: {
    headline: 'Adobe Premiere Pro — FCP7 XML / OTIO',
    body: 'Acesso limitado via FCP7 XML gerado pelo adapter OTIO. Clips, markers e nesting funcionam. Effects, transitions e speed changes sao perdidos no adapter FCP7 XML. A unica forma atual de levar OTIO para o Premiere e via otioconvert para FCP7 XML. A extensao Protio (OTIO nativo no Premiere) esta em desenvolvimento.',
    pills: ['clips ✔', 'markers ✔', 'nesting ✔', 'multi-track ✔', 'transitions ✖', 'effects ✖', 'speed ✖', 'round-trip ✖'],
    code: `# Pipeline OTIO → Premiere Pro

# 1. Gerar .otio via CapIAu-Talho
# 2. Validar o arquivo OTIO
python validate_capiau_otio.py cena_01.otio

# 3. Converter para FCP7 XML
otioconvert -i cena_01.otio -o cena_01.xml -a fcp_xml

# 4. Empacotar com midia (opcional)
otioz -i cena_01.otio -o entrega_cena_01.otioz

# 5. Importar no Premiere Pro
# File > Import > selecionar cena_01.xml
# Premiere criara bins e sequences automaticamente

# Regras criticas:
# - NUNCA gerar Transition objects no OTIO
# - NUNCA gerar Effect objects no OTIO  
# - NUNCA usar LinearTimeWarp ou FreezeFrame
# - Usar apenas ExternalReference ( MissingReference )`,
    links: [
      { label: 'OpenTimelineIO Adapters', url: 'https://opentimelineio.readthedocs.io/en/latest/tutorials/adapters.html' },
      { label: 'Protio (WIP)', url: 'https://github.com/opencollab/Protio' },
    ],
  },
};

export default function NLETabs() {
  const [activeTab, setActiveTab] = useState('kdenlive');
  const sectionRef = useRef<HTMLElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;
    gsap.from('.nle-tabs-bar', {
      opacity: 0, y: 20, duration: 0.6, ease: 'power2.out',
      scrollTrigger: { trigger: sectionRef.current, start: 'top 80%' },
    });
  }, { scope: sectionRef });

  const content = nleContent[activeTab];

  return (
    <section ref={sectionRef} id="nles" className="py-24 lg:py-32 bg-[#0D0D0C]">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        {/* Tab bar */}
        <div className="nle-tabs-bar flex flex-wrap gap-2 mb-10">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-6 py-2.5 text-sm font-medium rounded transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-[#E85D3E] text-[#0D0D0C] font-semibold'
                  : 'bg-transparent text-[#8A8A80] hover:text-[#F5F5F0]'
              }`}
              role="tab"
              aria-selected={activeTab === tab.id}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div key={activeTab} className="grid grid-cols-1 lg:grid-cols-[60%_40%] gap-10 lg:gap-12 animate-in fade-in duration-400">
          {/* Left: Text */}
          <div>
            <h3 className="text-[28px] font-bold text-[#F5F5F0] tracking-[-0.01em] mb-4">
              {content.headline}
            </h3>
            <p className="section-body mb-6">{content.body}</p>

            {/* Feature pills */}
            <div className="flex flex-wrap gap-2 mb-6">
              {content.pills.map((pill) => (
                <span
                  key={pill}
                  className="px-3 py-1 border border-[#2A2A25] rounded text-[11px] font-mono text-[#8A8A80]"
                >
                  {pill}
                </span>
              ))}
            </div>

            {/* Links */}
            <div className="flex flex-wrap gap-4">
              {content.links.map((link) => (
                <a
                  key={link.url}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-[#61AFEF] hover:text-[#E85D3E] underline transition-colors"
                >
                  {link.label}
                </a>
              ))}
            </div>
          </div>

          {/* Right: Code */}
          <div>
            <CodeBlock code={content.code} />
          </div>
        </div>
      </div>
    </section>
  );
}
