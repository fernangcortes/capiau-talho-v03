import { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const pipelineSteps = [
  {
    title: 'CapIAu-Talho (IA Core)',
    description: 'Analise semantica do material bruto, transcricao, diarizacao, busca vetorial em < 5ms e clustering narrativo via DeepSeek V3',
    number: '01',
  },
  {
    title: 'Decisao de Backend',
    description: 'A IA decide qual gerador usar baseado nas features requisitadas: effects? transitions? speed? compositing? delivery?',
    number: '02',
  },
  {
    title: 'Geradores',
    description: 'MLT XML (.kdenlive) · Blender Python (.py) · Resolve Python (.py) · OTIO (.otio) · MCP Server',
    number: '03',
  },
  {
    title: 'NLE / Ferramenta',
    description: 'Kdenlive · Blender VSE · DaVinci Resolve · Premiere Pro · Unreal Engine · Reaper · Nuke',
    number: '04',
  },
  {
    title: 'Edicao Manual (opcional)',
    description: 'Refinamento humano quando a integracao nao cobre 100% das features — transitions, color grading fino, sound design',
    number: '05',
  },
  {
    title: 'Render / Delivery',
    description: 'Output final via melt (MLT), bpy.render (Blender), Resolve Render Queue, Movie Render Queue (UE5), ou Reaper batch',
    number: '06',
  },
];

export default function Pipeline() {
  const sectionRef = useRef<HTMLElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;

    gsap.from('.pipeline-label', {
      opacity: 0, duration: 0.6, ease: 'power2.out',
      scrollTrigger: { trigger: sectionRef.current, start: 'top 75%' },
    });
    gsap.from('.pipeline-headline', {
      opacity: 0, y: 20, duration: 0.7, ease: 'power2.out', delay: 0.1,
      scrollTrigger: { trigger: sectionRef.current, start: 'top 75%' },
    });
    gsap.from('.pipeline-step', {
      opacity: 0, x: -30, duration: 0.7, ease: 'power2.out', stagger: 0.15,
      scrollTrigger: { trigger: '.pipeline-steps', start: 'top 75%' },
    });
    gsap.from('.pipeline-line', {
      scaleY: 0, transformOrigin: 'top', duration: 0.4, ease: 'power2.out', stagger: 0.15,
      scrollTrigger: { trigger: '.pipeline-steps', start: 'top 75%' },
    });
  }, { scope: sectionRef });

  return (
    <section ref={sectionRef} id="pipeline" className="py-24 lg:py-32 bg-[#141412]">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        <span className="pipeline-label label-accent block mb-4">Arquitetura</span>
        <h2 className="pipeline-headline section-headline mb-3">
          Pipeline de Integracao CapIAu-Talho
        </h2>
        <p className="section-body mb-12 max-w-[600px]">
          Do prompt a timeline editavel — como cada backend se encaixa no fluxo de producao.
        </p>

        <div className="pipeline-steps relative">
          {/* Vertical connecting line */}
          <div className="absolute left-[19px] top-0 bottom-0 w-0.5 bg-[#2A2A25]" />

          <div className="space-y-6">
            {pipelineSteps.map((step) => (
              <div key={step.number} className="pipeline-step flex items-start gap-5">
                {/* Number */}
                <span className="relative z-10 flex-shrink-0 w-10 h-10 flex items-center justify-center bg-[#0D0D0C] border border-[#2A2A25] rounded-full font-mono text-sm text-[#E85D3E]">
                  {step.number}
                </span>

                {/* Card */}
                <div className="flex-1 bg-[#0D0D0C] border border-[#2A2A25] rounded-lg p-5 hover:border-[#3D3D36] transition-colors">
                  <h3 className="text-base font-semibold text-[#F5F5F0]">{step.title}</h3>
                  <p className="text-sm text-[#8A8A80] mt-1 leading-relaxed">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
