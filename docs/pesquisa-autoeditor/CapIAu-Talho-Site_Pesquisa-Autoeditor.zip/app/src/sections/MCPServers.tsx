import { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface MCPCard {
  name: string;
  description: string;
  tools: string[];
  status: 'Open Source' | 'Commercial';
  github?: string;
  website?: string;
}

const mcpServers: MCPCard[] = [
  {
    name: 'Palmier Pro',
    description: 'Editor de video macOS open source com MCP server embutido. Agente e timeline no mesmo lugar. Gera clips com Seedance/Kling, edita via Claude/Cursor/Codex. Exporta MP4, ProRes e NLE XML.',
    tools: ['timeline.read', 'clip.add', 'clip.trim', 'generate.video', 'export.mp4'],
    status: 'Open Source',
    github: 'github.com/palmier-io/palmier-pro',
    website: 'https://www.palmier.io',
  },
  {
    name: 'DaVinci Resolve MCP',
    description: '45+ tools em 11 categorias. Controle completo de projects, timelines, media pool, color grading, Fusion, Fairlight e render via natural language. Requer Resolve Studio rodando localmente.',
    tools: ['project.create', 'timeline.edit', 'color.grade', 'render.export', 'Fusion.compose', 'execute_python'],
    status: 'Open Source',
    github: 'github.com/samuelgursky/davinci-resolve-mcp',
  },
  {
    name: 'vfx-mcp',
    description: 'Server MCP baseado em FFmpeg com 26 tools para edicao programatica. Trim, concat, format conversion, effects, overlays, subtitles, speed control. Interface via MCP Server, Python client API e CLI.',
    tools: ['trim_video', 'concatenate', 'add_subtitles', 'extract_audio', 'apply_filter', 'resize_video'],
    status: 'Open Source',
    github: 'github.com/conneroisu/vfx-mcp',
  },
  {
    name: 'Blender MCP',
    description: 'Natural language control do Blender via Python scripting. Modelagem 3D, animacao, compositing, VSE e render via comandos em linguagem natural. Requer addon MCP instalado no Blender.',
    tools: ['scene.create', 'object.add', 'material.apply', 'render.execute', 'animation.keyframe'],
    status: 'Open Source',
    github: 'github.com/ahujasid/blender-mcp',
  },
  {
    name: 'Video Jungle MCP',
    description: 'Edicao de video via OTIO com export para DaVinci Resolve Studio. Upload, analise, busca semantica e geracao de edits a partir de prompts. Integra com macOS Photos app.',
    tools: ['video.upload', 'search.embeddings', 'edit.generate', 'otio.export', 'project.manage'],
    status: 'Commercial',
    github: 'github.com/burningion/video-editor-mcp',
  },
  {
    name: 'reap.video MCP',
    description: 'AI clipping, captioning em 100+ idiomas e dubbing em 80+ idiomas. Detecta momentos virais, gera shorts, adiciona legendas animadas e reframing para qualquer aspect ratio.',
    tools: ['clip.viral', 'caption.add', 'dub.video', 'reframe.aspect', 'batch.process'],
    status: 'Commercial',
    website: 'https://mcp.reap.video',
  },
];

const statusColors = {
  'Open Source': { bg: '#4EC9B0', text: '#0D0D0C' },
  'Commercial': { bg: '#E5C07B', text: '#0D0D0C' },
};

export default function MCPServers() {
  const sectionRef = useRef<HTMLElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top 85%',
        toggleActions: 'play none none none',
      },
    });

    tl.fromTo('.mcp-label', { opacity: 0 }, { opacity: 1, duration: 0.6, ease: 'power2.out' })
      .fromTo('.mcp-headline', { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: 0.8, ease: 'power2.out' }, '-=0.4')
      .fromTo('.mcp-subtitle', { opacity: 0 }, { opacity: 1, duration: 0.6, ease: 'power2.out' }, '-=0.4');

    gsap.fromTo('.mcp-card',
      { opacity: 0, y: 25 },
      {
        opacity: 1, y: 0, duration: 0.6, ease: 'power2.out', stagger: 0.1,
        scrollTrigger: {
          trigger: '.mcp-grid',
          start: 'top 90%',
          toggleActions: 'play none none none',
        },
      }
    );
  }, { scope: sectionRef });

  return (
    <section ref={sectionRef} id="mcp" className="py-24 lg:py-32 bg-[#141412]">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        <span className="mcp-label label-accent block mb-4">Model Context Protocol</span>
        <h2 className="mcp-headline section-headline mb-3">
          MCP Servers — O Novo Paradigma de Integracao
        </h2>
        <p className="mcp-subtitle section-body mb-12 max-w-[800px]">
          O Model Context Protocol da Anthropic permite que agentes de IA controlem ferramentas de video diretamente via linguagem natural. Aqui estao os MCP servers mais relevantes para producao. A integracao do CapIAu-Talho com MCP servers e o proximo passo natural — conectar a analise semantica do CapIAu a acoes diretas em NLEs via agentes de IA.
        </p>

        <div className="mcp-grid grid grid-cols-1 lg:grid-cols-2 gap-6">
          {mcpServers.map((server) => (
            <div
              key={server.name}
              className="mcp-card bg-[#0D0D0C] border border-[#2A2A25] rounded-lg p-7 hover:border-[#3D3D36] hover:-translate-y-0.5 transition-all duration-200"
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xl font-semibold text-[#F5F5F0]">{server.name}</h3>
                <span
                  className="px-2 py-0.5 rounded text-[10px] font-mono uppercase font-medium"
                  style={{
                    backgroundColor: statusColors[server.status].bg,
                    color: statusColors[server.status].text,
                  }}
                >
                  {server.status}
                </span>
              </div>

              {/* Description */}
              <p className="text-sm text-[#8A8A80] leading-relaxed mb-4">{server.description}</p>

              {/* Tools */}
              <div className="flex flex-wrap gap-1.5 mb-4">
                {server.tools.map((tool) => (
                  <span
                    key={tool}
                    className="px-2.5 py-0.5 border border-[#2A2A25] rounded text-[11px] font-mono text-[#7EC699]"
                  >
                    {tool}
                  </span>
                ))}
              </div>

              {/* Link */}
              {server.github && (
                <a
                  href={`https://${server.github}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block text-xs font-mono text-[#61AFEF] hover:text-[#E85D3E] transition-colors"
                >
                  {server.github}
                </a>
              )}
              {server.website && (
                <a
                  href={server.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block text-xs font-mono text-[#61AFEF] hover:text-[#E85D3E] transition-colors"
                >
                  {server.website}
                </a>
              )}
            </div>
          ))}
        </div>

        {/* Additional MCP context */}
        <div className="mt-12 bg-[#0D0D0C] border border-[#2A2A25] rounded-lg p-6">
          <h3 className="text-base font-semibold text-[#F5F5F0] mb-3">Como funciona o MCP para video editing?</h3>
          <p className="text-sm text-[#8A8A80] leading-relaxed mb-4">
            O Model Context Protocol (MCP) e um padrao aberto da Anthropic que define como modelos de IA se comunicam com ferramentas externas. Um MCP server e um processo leve que expoe funcoes de uma API ou aplicativo em um formato que o modelo de IA entende. Quando o Claude (ou outro cliente MCP) se conecta a um server, ele pode listar ferramentas disponiveis, chama-las com parametros, e encadear multiplas chamadas para completar tarefas complexas.
          </p>
          <p className="text-sm text-[#8A8A80] leading-relaxed mb-4">
            Para o CapIAu-Talho, isso significa que um agente de IA pode: (1) analisar 20h de material bruto via CapIAu, (2) identificar os melhores soundbites e b-roll via busca semantica, (3) gerar uma timeline OTIO, (4) conectar via MCP a um NLE, e (5) executar a edicao diretamente no software — tudo em uma unica conversa.
          </p>
          <div className="flex flex-wrap gap-3">
            <a href="https://modelcontextprotocol.io" target="_blank" rel="noopener noreferrer" className="text-xs text-[#61AFEF] hover:text-[#E85D3E] underline transition-colors">
              modelcontextprotocol.io
            </a>
            <a href="https://www.anthropic.com/news/model-context-protocol" target="_blank" rel="noopener noreferrer" className="text-xs text-[#61AFEF] hover:text-[#E85D3E] underline transition-colors">
              Anthropic MCP Announcement
            </a>
            <a href="https://github.com/modelcontextprotocol" target="_blank" rel="noopener noreferrer" className="text-xs text-[#61AFEF] hover:text-[#E85D3E] underline transition-colors">
              MCP GitHub
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
