import { useState, useEffect } from 'react';
import { Menu, X, Github } from 'lucide-react';

const navLinks = [
  { label: 'Inicio', href: '#hero' },
  { label: 'NLEs', href: '#comparativo' },
  { label: 'MCP', href: '#mcp' },
  { label: 'Ferramentas', href: '#ferramentas' },
  { label: 'Pipeline', href: '#pipeline' },
  { label: 'Roadmap', href: '#roadmap' },
];

export default function Navigation() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const el = document.querySelector(href);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
      setMobileOpen(false);
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 h-14 px-6 lg:px-8 flex items-center justify-between transition-all duration-300 ${
        scrolled
          ? 'bg-[#0D0D0C]/95 backdrop-blur-xl border-b border-[#2A2A25]'
          : 'bg-transparent'
      }`}
    >
      {/* Logo */}
      <a
        href="#hero"
        onClick={(e) => handleClick(e, '#hero')}
        className="flex items-center gap-2 group"
      >
        <span className="w-1.5 h-1.5 rounded-full bg-[#E85D3E]" />
        <span className="text-sm font-semibold text-[#F5F5F0] tracking-tight">
          CapIAu-Talho
        </span>
      </a>

      {/* Desktop links */}
      <div className="hidden md:flex items-center gap-1">
        {navLinks.map((link) => (
          <a
            key={link.href}
            href={link.href}
            onClick={(e) => handleClick(e, link.href)}
            className="px-3 py-1.5 text-sm font-medium text-[#8A8A80] hover:text-[#F5F5F0] transition-colors duration-200"
          >
            {link.label}
          </a>
        ))}
      </div>

      {/* GitHub + Mobile toggle */}
      <div className="flex items-center gap-3">
        <a
          href="https://github.com/fernangcortes/capiau-talho-v03"
          target="_blank"
          rel="noopener noreferrer"
          className="hidden md:flex items-center gap-2 px-4 py-1.5 text-sm font-medium text-[#8A8A80] border border-[#2A2A25] rounded hover:border-[#E85D3E] hover:text-[#E85D3E] transition-all duration-200"
        >
          <Github className="w-4 h-4" />
          GitHub
        </a>

        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="md:hidden p-2 text-[#8A8A80] hover:text-[#F5F5F0]"
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="absolute top-14 left-0 right-0 bg-[#0D0D0C] border-b border-[#2A2A25] md:hidden">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => handleClick(e, link.href)}
              className="block px-6 py-3 text-sm font-medium text-[#8A8A80] hover:text-[#F5F5F0] hover:bg-[#141412] transition-colors"
            >
              {link.label}
            </a>
          ))}
          <a
            href="https://github.com/fernangcortes/capiau-talho-v03"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-6 py-3 text-sm font-medium text-[#8A8A80] hover:text-[#F5F5F0] hover:bg-[#141412]"
          >
            <Github className="w-4 h-4" />
            GitHub
          </a>
        </div>
      )}
    </nav>
  );
}
