import ParticleCanvas from '../components/ParticleCanvas';

export default function Hero() {
  const handleExplore = (e: React.MouseEvent<HTMLButtonElement>, target: string) => {
    e.preventDefault();
    const el = document.querySelector(target);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="hero" className="relative min-h-[100dvh] flex items-center overflow-hidden">
      <ParticleCanvas />

      <div className="relative z-10 px-6 sm:px-10 lg:px-20 max-w-[720px]">
        <span className="font-mono text-xs uppercase tracking-[0.12em] text-[#E85D3E] block mb-6">
          Integracao · APIs · MCP · Scripts
        </span>

        <h1 className="text-[40px] sm:text-[56px] lg:text-[72px] font-bold tracking-[-0.03em] leading-[1.1]">
          <span className="block text-[#F5F5F0]">CapIAu-Talho</span>
          <span className="block text-[#E85D3E]">Ecosystem Hub</span>
        </h1>

        <p className="mt-6 text-base sm:text-lg text-[#8A8A80] leading-relaxed max-w-[560px]">
          Mapeamento completo de possibilidades de integracao do CapIAu-Talho com NLEs, engines, DAWs, MCP servers e ferramentas de producao via OTIO, APIs, SDKs e programacao.
        </p>

        <div className="mt-10 flex flex-wrap gap-4">
          <button
            onClick={(e) => handleExplore(e, '#comparativo')}
            className="px-7 py-3 bg-[#E85D3E] text-[#0D0D0C] text-sm font-semibold rounded hover:bg-[#FF7A5C] transition-all duration-200"
          >
            Explorar NLEs
          </button>
          <button
            onClick={(e) => handleExplore(e, '#mcp')}
            className="px-7 py-3 bg-transparent border border-[#2A2A25] text-[#F5F5F0] text-sm font-medium rounded hover:border-[#E85D3E] transition-all duration-200"
          >
            Ver MCP Servers
          </button>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center z-10">
        <div className="w-px h-10 bg-[#2A2A25] relative">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-[#E85D3E] scroll-indicator-dot" />
        </div>
      </div>
    </section>
  );
}
