import { useRef, useState } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface NLERow {
  name: string;
  format: string;
  createTimeline: string;
  multiTracks: string;
  effects: string;
  transitions: string;
  keyframes: string;
  speed: string;
  compositing: string;
  text: string;
  renderCode: string;
  cost: string;
  recommendation: string;
  category: 'opensource' | 'commercial' | 'hybrid';
}

const nleData: NLERow[] = [
  { name: 'Kdenlive', format: 'MLT XML', createTimeline: '✔', multiTracks: '✔', effects: '✔', transitions: '✔', keyframes: '✔', speed: '✔', compositing: '✔', text: '✔', renderCode: '✔ (melt)', cost: 'Gratis', recommendation: '⭐⭐⭐⭐⭐', category: 'opensource' },
  { name: 'Blender VSE', format: 'Python API', createTimeline: '✔', multiTracks: '✔', effects: '✔', transitions: '✔', keyframes: '✔', speed: '✔', compositing: '✔ (nodes)', text: '✔', renderCode: '✔', cost: 'Gratis', recommendation: '⭐⭐⭐⭐⭐', category: 'opensource' },
  { name: 'DaVinci Resolve', format: 'Python API', createTimeline: '✔', multiTracks: '✔', effects: '✖', transitions: '✖', keyframes: '✖', speed: '✖', compositing: '✔ (Fusion)', text: '✔', renderCode: '✔', cost: 'Pago (Studio)', recommendation: '⭐⭐⭐⭐', category: 'commercial' },
  { name: 'Premiere Pro', format: 'FCP7 XML', createTimeline: '✔', multiTracks: '✔', effects: '✖', transitions: '✖', keyframes: '✖', speed: '✖', compositing: '✖', text: '✖', renderCode: '✖', cost: 'Pago (CC)', recommendation: '⭐⭐', category: 'commercial' },
  { name: 'Shotcut', format: 'MLT XML', createTimeline: '✔', multiTracks: '✔', effects: '✔', transitions: '✔', keyframes: '✔', speed: '✔', compositing: '✔', text: '✔', renderCode: '✔ (melt)', cost: 'Gratis', recommendation: '⭐⭐⭐', category: 'opensource' },
  { name: 'Remotion', format: 'React/TS', createTimeline: '✔', multiTracks: '✔', effects: '✔', transitions: '✔', keyframes: '✔', speed: '✔', compositing: '✔', text: '✔', renderCode: '✔', cost: 'Gratis', recommendation: '⭐⭐⭐', category: 'hybrid' },
  { name: 'Olive Editor', format: 'N/A', createTimeline: '~', multiTracks: '~', effects: '✖', transitions: '✖', keyframes: '✖', speed: '✖', compositing: '✖', text: '✖', renderCode: '✖', cost: 'Gratis', recommendation: '⭐', category: 'opensource' },
];

const categoryColors: Record<string, string> = {
  opensource: '#4EC9B0',
  commercial: '#61AFEF',
  hybrid: '#C678DD',
};

function StatusIcon({ value }: { value: string }) {
  if (value.startsWith('✔')) return <span className="text-[#4EC9B0] font-bold">{value}</span>;
  if (value === '✖') return <span className="text-[#E85D3E] font-bold">{value}</span>;
  return <span className="text-[#E5C07B] font-bold">{value}</span>;
}

export default function Comparativo() {
  const sectionRef = useRef<HTMLElement>(null);
  const [sortCol, setSortCol] = useState<number | null>(null);
  const [sortAsc, setSortAsc] = useState(true);

  useGSAP(() => {
    if (!sectionRef.current) return;

    gsap.from('.comp-label', {
      opacity: 0, duration: 0.6, ease: 'power2.out',
      scrollTrigger: { trigger: sectionRef.current, start: 'top 75%' },
    });
    gsap.from('.comp-headline', {
      opacity: 0, y: 20, duration: 0.7, ease: 'power2.out', delay: 0.1,
      scrollTrigger: { trigger: sectionRef.current, start: 'top 75%' },
    });
    gsap.from('.comp-row', {
      opacity: 0, y: 15, duration: 0.5, ease: 'power2.out', stagger: 0.06,
      scrollTrigger: { trigger: '.comp-table', start: 'top 80%' },
    });
    gsap.from('.comp-card', {
      opacity: 0, y: 20, duration: 0.6, ease: 'power2.out', stagger: 0.1,
      scrollTrigger: { trigger: '.comp-cards', start: 'top 85%' },
    });
  }, { scope: sectionRef });

  const headers = ['NLE', 'Formato', 'Timeline', 'Tracks', 'Effects', 'Trans.', 'KF', 'Speed', 'Comp.', 'Text', 'Render', 'Custo', 'Nota'];

  const handleSort = (colIndex: number) => {
    if (colIndex === 0 || colIndex === 1 || colIndex === 11 || colIndex === 12) {
      if (sortCol === colIndex) {
        setSortAsc(!sortAsc);
      } else {
        setSortCol(colIndex);
        setSortAsc(true);
      }
    }
  };

  const getSortValue = (row: NLERow, col: number): string => {
    switch (col) {
      case 0: return row.name;
      case 1: return row.format;
      case 11: return row.cost;
      case 12: return row.recommendation;
      default: return '';
    }
  };

  const sortedData = sortCol !== null
    ? [...nleData].sort((a, b) => {
        const aVal = getSortValue(a, sortCol);
        const bVal = getSortValue(b, sortCol);
        return sortAsc ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      })
    : nleData;

  return (
    <section ref={sectionRef} id="comparativo" className="py-24 lg:py-32 bg-[#141412]">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        <span className="comp-label label-accent block mb-4">Comparativo</span>
        <h2 className="comp-headline section-headline mb-3">
          Matriz de Compatibilidade — NLEs x Formatos x APIs
        </h2>
        <p className="section-body mb-10 max-w-[700px]">
          Cada NLE oferece caminhos diferentes para integracao programatica. Aqui esta o panorama completo.
        </p>

        {/* Table */}
        <div className="comp-table overflow-x-auto -mx-6 px-6">
          <table className="w-full min-w-[900px] border-collapse">
            <thead>
              <tr className="bg-[#1C1C19] border-b-2 border-[#2A2A25]">
                {headers.map((h, i) => (
                  <th
                    key={h}
                    onClick={() => handleSort(i)}
                    className={`text-left px-4 py-3 font-mono text-[11px] uppercase tracking-wider text-[#8A8A80] whitespace-nowrap ${
                      (i === 0 || i === 1 || i === 11 || i === 12) ? 'cursor-pointer hover:text-[#F5F5F0]' : ''
                    }`}
                  >
                    <span className="flex items-center gap-1">
                      {h}
                      {sortCol === i && (
                        <span className="text-[#E85D3E]">{sortAsc ? '↑' : '↓'}</span>
                      )}
                    </span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sortedData.map((row, idx) => (
                <tr
                  key={row.name}
                  className={`comp-row border-b border-[#1C1C19] transition-colors duration-150 hover:bg-[#1C1C19] ${
                    idx % 2 === 0 ? 'bg-[#0D0D0C]' : 'bg-[#141412]'
                  }`}
                >
                  <td className="px-4 py-3.5 whitespace-nowrap">
                    <span className="flex items-center gap-2">
                      <span
                        className="w-2 h-2 rounded-full flex-shrink-0"
                        style={{ backgroundColor: categoryColors[row.category] }}
                      />
                      <span className="text-sm font-semibold text-[#F5F5F0]">{row.name}</span>
                    </span>
                  </td>
                  <td className="px-4 py-3.5 text-sm text-[#8A8A80] whitespace-nowrap">{row.format}</td>
                  <td className="px-4 py-3.5 text-sm"><StatusIcon value={row.createTimeline} /></td>
                  <td className="px-4 py-3.5 text-sm"><StatusIcon value={row.multiTracks} /></td>
                  <td className="px-4 py-3.5 text-sm"><StatusIcon value={row.effects} /></td>
                  <td className="px-4 py-3.5 text-sm"><StatusIcon value={row.transitions} /></td>
                  <td className="px-4 py-3.5 text-sm"><StatusIcon value={row.keyframes} /></td>
                  <td className="px-4 py-3.5 text-sm"><StatusIcon value={row.speed} /></td>
                  <td className="px-4 py-3.5 text-sm"><StatusIcon value={row.compositing} /></td>
                  <td className="px-4 py-3.5 text-sm"><StatusIcon value={row.text} /></td>
                  <td className="px-4 py-3.5 text-sm"><StatusIcon value={row.renderCode} /></td>
                  <td className="px-4 py-3.5 text-sm text-[#8A8A80] whitespace-nowrap">{row.cost}</td>
                  <td className="px-4 py-3.5 text-sm text-[#E5C07B] whitespace-nowrap">{row.recommendation}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Info cards */}
        <div className="comp-cards grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
          <div className="comp-card bg-[#0D0D0C] border border-[#2A2A25] rounded-lg p-6">
            <h3 className="text-sm font-semibold text-[#F5F5F0] mb-2">OTIO e a ponte universal</h3>
            <p className="text-sm text-[#8A8A80] leading-relaxed">
              OpenTimelineIO serve como formato de intercambio agnostico entre NLEs. Nao codifica midia — apenas estrutura editorial, intencao de corte e metadados. Suportado nativamente no Kdenlive 25.04+.
            </p>
            <a href="https://opentimelineio.readthedocs.io" target="_blank" rel="noopener noreferrer" className="inline-block mt-3 text-xs text-[#61AFEF] hover:text-[#E85D3E] underline transition-colors">
              opentimelineio.readthedocs.io
            </a>
          </div>
          <div className="comp-card bg-[#0D0D0C] border border-[#2A2A25] rounded-lg p-6">
            <h3 className="text-sm font-semibold text-[#F5F5F0] mb-2">MLT XML = acesso total</h3>
            <p className="text-sm text-[#8A8A80] leading-relaxed">
              Geracao direta de MLT XML (.kdenlive) da acesso completo a effects, transitions, filters, keyframes, compositing, time remapping e nested tractors — tudo via codigo, sem limitacoes de adapters.
            </p>
            <a href="https://github.com/KDE/kdenlive/blob/master/dev-docs/fileformat.md" target="_blank" rel="noopener noreferrer" className="inline-block mt-3 text-xs text-[#61AFEF] hover:text-[#E85D3E] underline transition-colors">
              Kdenlive File Format Docs
            </a>
          </div>
          <div className="comp-card bg-[#0D0D0C] border border-[#2A2A25] rounded-lg p-6">
            <h3 className="text-sm font-semibold text-[#F5F5F0] mb-2">MCP Servers = novo paradigma</h3>
            <p className="text-sm text-[#8A8A80] leading-relaxed">
              Model Context Protocol da Anthropic permite que agentes de IA controlem NLEs diretamente via linguagem natural. Palmier Pro, DaVinci Resolve MCP e vfx-mcp ja operam nesse modelo.
            </p>
            <a href="https://modelcontextprotocol.io" target="_blank" rel="noopener noreferrer" className="inline-block mt-3 text-xs text-[#61AFEF] hover:text-[#E85D3E] underline transition-colors">
              modelcontextprotocol.io
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
