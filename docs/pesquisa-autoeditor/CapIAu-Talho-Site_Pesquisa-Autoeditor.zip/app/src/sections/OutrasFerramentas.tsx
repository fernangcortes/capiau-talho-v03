import { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Clapperboard, AudioLines, Sparkles, FolderOpen, Code2, Layers } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Tool {
  name: string;
  status: 'available' | 'partial' | 'limited';
}

interface ToolCard {
  title: string;
  icon: React.ReactNode;
  description: string;
  tools: Tool[];
  links?: { label: string; url: string }[];
}

const toolCards: ToolCard[] = [
  {
    title: 'Unreal Engine 5',
    icon: <Clapperboard className="w-7 h-7 text-[#E85D3E]" />,
    description: 'Plugin OTIO oficial da Epic. Mapeia timelines para Level Sequences. Suporta multi-tracks, markers, nesting e linear speed. Audio tracks e transitions ainda nao suportados. API Python para Sequencer e Movie Render Queue.',
    tools: [
      { name: 'Plugin OTIO-UE', status: 'available' },
      { name: 'Python Sequencer API', status: 'available' },
      { name: 'Movie Render Queue', status: 'available' },
      { name: 'Audio tracks', status: 'limited' },
      { name: 'Transitions', status: 'limited' },
    ],
    links: [
      { label: 'OpenTimelineIO-Unreal-Plugin', url: 'https://github.com/EpicGames/OpenTimelineIO-Unreal-Plugin' },
      { label: 'Unreal Python Docs', url: 'https://docs.unrealengine.com/5.0/en-US/scripting-the-unreal-editor-using-python/' },
    ],
  },
  {
    title: 'Audio / DAWs',
    icon: <AudioLines className="w-7 h-7 text-[#E85D3E]" />,
    description: 'Reaper oferece REAScript (Python/Lua/EEL) com acesso completo a tracks, items, FX, automacao e markers. FFmpeg processa audio/video via CLI. Audacity tem scripting experimental. Pro Tools limitado a AAF/OMF.',
    tools: [
      { name: 'Reaper REAScript', status: 'available' },
      { name: 'FFmpeg CLI', status: 'available' },
      { name: 'Audacity Scripting', status: 'partial' },
      { name: 'Pro Tools API', status: 'limited' },
    ],
    links: [
      { label: 'Reaper API', url: 'https://www.reaper.fm/sdk/reascript/reascript.php' },
      { label: 'FFmpeg Docs', url: 'https://ffmpeg.org/documentation.html' },
    ],
  },
  {
    title: 'VFX / Compositing',
    icon: <Sparkles className="w-7 h-7 text-[#E85D3E]" />,
    description: 'Nuke e Hiero oferecem Python API completa para projetos, sequences, tracks e node trees — com OTIO import/export desde v13.2. Blender Compositor Nodes sao 100% scriptaveis. DaVinci Fusion acessivel via Resolve API.',
    tools: [
      { name: 'Nuke Python API', status: 'available' },
      { name: 'Hiero API', status: 'available' },
      { name: 'Blender Compositor', status: 'available' },
      { name: 'Fusion Python', status: 'available' },
    ],
    links: [
      { label: 'Nuke Python Dev Guide', url: 'https://learn.foundry.com/nuke/developers/120/pythondevguide/' },
      { label: 'Hiero Python', url: 'https://learn.foundry.com/hiero/developers/1.8/hieropythondevguide/' },
    ],
  },
  {
    title: 'Gerenciamento de Projeto',
    icon: <FolderOpen className="w-7 h-7 text-[#E85D3E]" />,
    description: 'Autodesk ShotGrid usa OTIO como backing representation de timeline. ftrack cineSync 5 suporta OTIO para review e approval sincronizado. Animal Logic Editron compara versoes de cuts e empacota assets.',
    tools: [
      { name: 'ShotGrid + OTIO', status: 'available' },
      { name: 'cineSync 5', status: 'available' },
      { name: 'Editron', status: 'available' },
    ],
    links: [
      { label: 'ASWF', url: 'https://www.aswf.io' },
      { label: 'OTIO GitHub', url: 'https://github.com/AcademySoftwareFoundation/OpenTimelineIO' },
    ],
  },
  {
    title: 'Geracao Programatica',
    icon: <Code2 className="w-7 h-7 text-[#E85D3E]" />,
    description: 'Ferramentas para geracao de video via codigo: Remotion (React/TS com timeline puramente via codigo), Editly (FFmpeg/JSON para videos curtos), MoviePy (Python prototipagem), Shotstack (JSON API na nuvem).',
    tools: [
      { name: 'Remotion', status: 'available' },
      { name: 'Editly', status: 'available' },
      { name: 'MoviePy', status: 'available' },
      { name: 'Shotstack', status: 'available' },
    ],
    links: [
      { label: 'Remotion', url: 'https://www.remotion.dev' },
      { label: 'Editly GitHub', url: 'https://github.com/mifi/editly' },
    ],
  },
  {
    title: 'Frameworks Abertos',
    icon: <Layers className="w-7 h-7 text-[#E85D3E]" />,
    description: 'Pilha tecnologica open source da industria: OpenTimelineIO (intercambio de timelines), OpenColorIO (gerenciamento de cor), OpenImageIO (processamento de imagem), USD (descricao de cena 3D), Alembic (cache de geometria).',
    tools: [
      { name: 'OTIO', status: 'available' },
      { name: 'OCIO', status: 'available' },
      { name: 'OpenImageIO', status: 'available' },
      { name: 'USD', status: 'available' },
      { name: 'Alembic', status: 'available' },
    ],
    links: [
      { label: 'OpenTimelineIO', url: 'https://opentimelineio.readthedocs.io' },
      { label: 'ASWF Projects', url: 'https://www.aswf.io/projects' },
    ],
  },
];

const statusDotColors = {
  available: '#4EC9B0',
  partial: '#E5C07B',
  limited: '#E85D3E',
};

export default function OutrasFerramentas() {
  const sectionRef = useRef<HTMLElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;

    gsap.fromTo('.tools-label',
      { opacity: 0 },
      { opacity: 1, duration: 0.6, ease: 'power2.out',
        scrollTrigger: { trigger: sectionRef.current, start: 'top 85%', toggleActions: 'play none none none' }
      }
    );
    gsap.fromTo('.tools-headline',
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 0.7, ease: 'power2.out', delay: 0.1,
        scrollTrigger: { trigger: sectionRef.current, start: 'top 85%', toggleActions: 'play none none none' }
      }
    );
    gsap.fromTo('.tools-card',
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 0.5, ease: 'power2.out', stagger: 0.08,
        scrollTrigger: { trigger: '.tools-grid', start: 'top 90%', toggleActions: 'play none none none' }
      }
    );
  }, { scope: sectionRef });

  return (
    <section ref={sectionRef} id="ferramentas" className="py-24 lg:py-32 bg-[#0D0D0C]">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        <span className="tools-label label-accent block mb-4">Ecossistema Completo</span>
        <h2 className="tools-headline section-headline mb-10">
          Ferramentas Emergentes e Alternativas
        </h2>

        <div className="tools-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {toolCards.map((card) => (
            <div
              key={card.title}
              className="tools-card bg-[#141412] border border-[#2A2A25] rounded-lg p-7 hover:border-[#3D3D36] transition-all duration-200"
            >
              {/* Icon */}
              <div className="mb-4">{card.icon}</div>

              {/* Title */}
              <h3 className="text-lg font-semibold text-[#F5F5F0] mb-3">{card.title}</h3>

              {/* Description */}
              <p className="text-sm text-[#8A8A80] leading-relaxed mb-4">{card.description}</p>

              {/* Tool list */}
              <div className="space-y-1.5 mb-4">
                {card.tools.map((tool) => (
                  <div key={tool.name} className="flex items-center gap-2">
                    <span
                      className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                      style={{ backgroundColor: statusDotColors[tool.status] }}
                    />
                    <span className="text-sm text-[#8A8A80]">{tool.name}</span>
                  </div>
                ))}
              </div>

              {/* Links */}
              {card.links && (
                <div className="flex flex-wrap gap-3 pt-3 border-t border-[#2A2A25]">
                  {card.links.map((link) => (
                    <a
                      key={link.url}
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-[#61AFEF] hover:text-[#E85D3E] underline transition-colors"
                    >
                      {link.label}
                    </a>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
