import { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface Milestone {
  title: string;
  description: string;
  status: 'completed' | 'upcoming' | 'idea';
}

const milestones: Milestone[] = [
  {
    title: 'OTIO nativo Kdenlive',
    description: 'Kdenlive 25.04+ com import/export nativo de .otio sem adapters externos',
    status: 'completed',
  },
  {
    title: 'Correcao track order',
    description: 'Bug de inversao de tracks corrigido em builds pos-01/06/2025',
    status: 'completed',
  },
  {
    title: 'Image Sequence clips',
    description: 'Suporte a sequencias de imagens via OTIO nativo no Kdenlive',
    status: 'upcoming',
  },
  {
    title: 'Multi-timeline projects',
    description: 'Projetos com multiplas timelines via OTIO nativo',
    status: 'upcoming',
  },
  {
    title: 'OTIO Archive (.otioz)',
    description: 'Entrega portatil com midia embutida no Kdenlive',
    status: 'upcoming',
  },
  {
    title: 'MCP Server CapIAu-Talho',
    description: 'Server MCP proprio para controle direto do CapIAu-Talho via agentes de IA',
    status: 'upcoming',
  },
  {
    title: 'Blender GSoC 2026 OTIO',
    description: 'Import/export nativo de .otio no Blender VSE via Google Summer of Code',
    status: 'upcoming',
  },
  {
    title: 'Voice-Driven Editing',
    description: 'Speech-to-text + NLP para edicao por comandos de voz no CapIAu-Talho',
    status: 'idea',
  },
];

export default function Roadmap() {
  const sectionRef = useRef<HTMLElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;

    gsap.from('.roadmap-label', {
      opacity: 0, duration: 0.6, ease: 'power2.out',
      scrollTrigger: { trigger: sectionRef.current, start: 'top 80%' },
    });
    gsap.from('.roadmap-headline', {
      opacity: 0, y: 20, duration: 0.7, ease: 'power2.out', delay: 0.1,
      scrollTrigger: { trigger: sectionRef.current, start: 'top 80%' },
    });

    // Timeline line draws in
    gsap.from('.roadmap-line', {
      scaleY: 0, transformOrigin: 'top', duration: 0.8, ease: 'power2.inOut',
      scrollTrigger: { trigger: '.roadmap-timeline', start: 'top 75%' },
    });

    // Dots scale in
    gsap.from('.roadmap-dot', {
      scale: 0, duration: 0.4, ease: 'back.out(1.7)', stagger: 0.12,
      scrollTrigger: { trigger: '.roadmap-timeline', start: 'top 75%' },
    });

    // Content slides in
    gsap.from('.roadmap-item', {
      opacity: 0, x: 20, duration: 0.5, ease: 'power2.out', stagger: 0.12,
      scrollTrigger: { trigger: '.roadmap-timeline', start: 'top 75%' },
    });
  }, { scope: sectionRef });

  return (
    <section ref={sectionRef} id="roadmap" className="py-24 lg:py-32 bg-[#0D0D0C]">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        <span className="roadmap-label label-accent block mb-4">Futuro</span>
        <h2 className="roadmap-headline section-headline mb-12">
          Roadmap de Integracoes
        </h2>

        <div className="roadmap-timeline relative">
          {/* Center line (desktop) / left line (mobile) */}
          <div className="roadmap-line absolute left-5 lg:left-1/2 lg:-translate-x-px top-0 bottom-0 w-0.5 bg-[#2A2A25]" />

          <div className="space-y-8">
            {milestones.map((m, idx) => {
              const isLeft = idx % 2 === 0;
              const isCompleted = m.status === 'completed';

              return (
                <div
                  key={m.title}
                  className={`roadmap-item relative flex items-start gap-6 ${
                    isLeft ? 'lg:flex-row' : 'lg:flex-row-reverse'
                  }`}
                >
                  {/* Spacer for alternating layout on desktop */}
                  <div className="hidden lg:block lg:w-1/2" />

                  {/* Content card */}
                  <div className="flex-1 lg:w-1/2 pl-14 lg:pl-0">
                    <div
                      className={`${isLeft ? 'lg:pr-10' : 'lg:pl-10'}`}
                    >
                      <h3
                        className={`text-base font-semibold ${
                          isCompleted ? 'text-[#F5F5F0]' : 'text-[#8A8A80]'
                        }`}
                      >
                        {m.title}
                      </h3>
                      <p className="text-sm text-[#8A8A80] mt-1 leading-relaxed">
                        {m.description}
                      </p>
                      {m.status === 'idea' && (
                        <span className="inline-block mt-2 px-2 py-0.5 text-[10px] font-mono uppercase text-[#C678DD] border border-[#C678DD] rounded">
                          Ideia
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Dot */}
                  <div
                    className={`roadmap-dot absolute left-5 lg:left-1/2 lg:-translate-x-1/2 w-3 h-3 rounded-full border-2 ${
                      isCompleted
                        ? 'bg-[#E85D3E] border-[#E85D3E]'
                        : 'bg-[#0D0D0C] border-[#E85D3E]'
                    }`}
                    style={{ top: '6px' }}
                  />
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
