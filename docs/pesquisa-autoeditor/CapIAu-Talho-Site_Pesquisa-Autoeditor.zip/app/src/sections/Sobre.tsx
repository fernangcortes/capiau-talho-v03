import { useRef } from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import CodeBlock from '../components/CodeBlock';

gsap.registerPlugin(ScrollTrigger);

const architectureCode = `# CapIAu-Talho Architecture
FastAPI Backend (Python/CPU)
├── SQLite (metadados + falas)
├── Qdrant Local (busca vetorial)
├── FFmpeg (proxies + extracao)
├── AssemblyAI (ASR + diarizacao)
├── OpenRouter (visao + clustering)
└── Export: XML / OTIO / .kdenlive`;

export default function Sobre() {
  const sectionRef = useRef<HTMLElement>(null);

  useGSAP(() => {
    if (!sectionRef.current) return;

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
    });

    tl.from('.sobre-label', { opacity: 0, duration: 0.6, ease: 'power2.out' })
      .from('.sobre-headline', { opacity: 0, y: 30, duration: 0.8, ease: 'power2.out' }, '-=0.45')
      .from('.sobre-body', { opacity: 0, y: 20, duration: 0.7, ease: 'power2.out', stagger: 0.15 }, '-=0.5')
      .from('.sobre-code', { opacity: 0, x: 40, duration: 0.9, ease: 'power3.out' }, '-=0.6');
  }, { scope: sectionRef });

  return (
    <section
      ref={sectionRef}
      id="sobre"
      className="py-24 lg:py-32 bg-[#0D0D0C]"
    >
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-[55%_45%] gap-12 lg:gap-16 items-start">
          {/* Left: Text */}
          <div>
            <span className="sobre-label label-accent block mb-4">
              Sobre o Sistema
            </span>
            <h2 className="sobre-headline section-headline mb-6">
              Motor de Inteligencia e Decupagem Cinematografica
            </h2>
            <p className="sobre-body section-body mb-4">
              O CapIAu-Talho e uma solucao de IA e pre-edicao (decupagem) projetada para fluxos de Making Of e Documentarios. Roda em CPUs locais (Intel i7 + 32GB RAM) com busca vetorial local em CPU combinada com APIs de nuvem de baixo custo. Processa 20+ horas de material bruto, transcreve falas com diarizacao, busca semantica em &lt; 5ms e exporta timelines via XML e OpenTimelineIO.
            </p>
            <p className="sobre-body section-body">
              Este site e um panorama vivo de todas as formas de conectar o CapIAu-Talho ao ecossistema de producao — desde NLEs open-source ate MCP servers emergentes.
            </p>
          </div>

          {/* Right: Code block */}
          <div className="sobre-code">
            <CodeBlock code={architectureCode} />
          </div>
        </div>
      </div>
    </section>
  );
}
