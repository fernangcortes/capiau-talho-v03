import { Github, FileText, AlertCircle } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#141412] border-t border-[#2A2A25]">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-8 py-14 pb-10">
        {/* Row 1: Three columns */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-10">
          {/* Left: Logo */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="w-1.5 h-1.5 rounded-full bg-[#E85D3E]" />
              <span className="text-sm font-semibold text-[#F5F5F0]">CapIAu-Talho</span>
            </div>
            <p className="text-sm text-[#8A8A80]">Motor de Inteligencia Cinematografica</p>
          </div>

          {/* Center: Links */}
          <div>
            <h4 className="text-xs font-mono uppercase tracking-wider text-[#8A8A80] mb-4">Links</h4>
            <div className="space-y-2">
              <a
                href="https://github.com/fernangcortes/capiau-talho-v03"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-[#8A8A80] hover:text-[#F5F5F0] transition-colors"
              >
                <Github className="w-3.5 h-3.5" />
                GitHub
              </a>
              <a
                href="https://github.com/fernangcortes/capiau-talho-v03/blob/main/README.md"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-[#8A8A80] hover:text-[#F5F5F0] transition-colors"
              >
                <FileText className="w-3.5 h-3.5" />
                Documentacao
              </a>
              <a
                href="https://github.com/fernangcortes/capiau-talho-v03/issues"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-[#8A8A80] hover:text-[#F5F5F0] transition-colors"
              >
                <AlertCircle className="w-3.5 h-3.5" />
                Reportar Issue
              </a>
            </div>
          </div>

          {/* Right: External refs */}
          <div>
            <h4 className="text-xs font-mono uppercase tracking-wider text-[#8A8A80] mb-4">Referencias</h4>
            <div className="space-y-2">
              <a
                href="https://docs.kdenlive.org"
                target="_blank"
                rel="noopener noreferrer"
                className="block text-sm text-[#8A8A80] hover:text-[#F5F5F0] transition-colors"
              >
                Kdenlive Docs
              </a>
              <a
                href="https://opentimelineio.readthedocs.io"
                target="_blank"
                rel="noopener noreferrer"
                className="block text-sm text-[#8A8A80] hover:text-[#F5F5F0] transition-colors"
              >
                OpenTimelineIO
              </a>
              <a
                href="https://www.aswf.io"
                target="_blank"
                rel="noopener noreferrer"
                className="block text-sm text-[#8A8A80] hover:text-[#F5F5F0] transition-colors"
              >
                ASWF
              </a>
            </div>
          </div>
        </div>

        {/* Row 2: Disclaimer */}
        <div className="border-t border-[#1C1C19] pt-6">
          <p className="text-xs text-[#5C5C55] text-center leading-relaxed">
            Documentacao interativa para integracao do CapIAu-Talho com o ecossistema de producao.
            Nao e afiliado com nenhum dos programs mencionados. Todas as marcas registradas pertencem aos seus respectivos proprietarios.
          </p>
        </div>
      </div>
    </footer>
  );
}
