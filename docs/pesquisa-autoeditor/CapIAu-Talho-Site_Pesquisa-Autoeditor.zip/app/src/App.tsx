import Navigation from './sections/Navigation'
import Hero from './sections/Hero'
import Sobre from './sections/Sobre'
import Comparativo from './sections/Comparativo'
import NLETabs from './sections/NLETabs'
import MCPServers from './sections/MCPServers'
import OutrasFerramentas from './sections/OutrasFerramentas'
import Pipeline from './sections/Pipeline'
import Roadmap from './sections/Roadmap'
import Footer from './sections/Footer'

export default function App() {
  return (
    <div className="min-h-screen bg-[#0D0D0C]">
      <Navigation />
      <Hero />
      <Sobre />
      <Comparativo />
      <NLETabs />
      <MCPServers />
      <OutrasFerramentas />
      <Pipeline />
      <Roadmap />
      <Footer />
    </div>
  )
}
