interface CodeBlockProps {
  code: string;
}

export default function CodeBlock({ code }: CodeBlockProps) {
  const lines = code.split('\n');

  const renderLine = (line: string, i: number) => {
    // Comments
    if (line.trim().startsWith('#')) {
      return (
        <span key={i} className="block">
          <span className="text-[#5C6370]">{line}</span>
        </span>
      );
    }

    // Empty lines
    if (line.trim() === '') {
      return <span key={i} className="block">&nbsp;</span>;
    }

    // Function calls
    const funcMatch = line.match(/^(\s*)([\w_]+)(\s*\()/);
    if (funcMatch) {
      const prefix = funcMatch[1];
      const funcName = funcMatch[2];
      const paren = funcMatch[3];
      const rest = line.slice(funcMatch[0].length);

      return (
        <span key={i} className="block">
          <span className="text-[#F5F5F0]">{prefix}</span>
          <span className="text-[#61AFEF]">{funcName}</span>
          <span className="text-[#F5F5F0]">{paren}</span>
          <span className="text-[#F5F5F0]">{rest}</span>
        </span>
      );
    }

    // Strings
    if (line.includes('"') || line.includes("'")) {
      const parts: React.ReactNode[] = [];
      const stringRegex = /(["'])(?:(?=(\\?))\2[\s\S])*?\1/g;
      let lastIndex = 0;
      let match;
      let keyIdx = 0;

      while ((match = stringRegex.exec(line)) !== null) {
        if (match.index > lastIndex) {
          parts.push(<span key={keyIdx++} className="text-[#F5F5F0]">{line.slice(lastIndex, match.index)}</span>);
        }
        parts.push(<span key={keyIdx++} className="text-[#7EC699]">{match[0]}</span>);
        lastIndex = match.index + match[0].length;
      }
      if (lastIndex < line.length) {
        parts.push(<span key={keyIdx++} className="text-[#F5F5F0]">{line.slice(lastIndex)}</span>);
      }

      return <span key={i} className="block">{parts}</span>;
    }

    // Default
    return (
      <span key={i} className="block text-[#F5F5F0]">
        {line}
      </span>
    );
  };

  return (
    <div className="bg-[#1C1C19] border border-[#2A2A25] rounded-lg overflow-hidden">
      {/* Terminal title bar */}
      <div className="flex items-center gap-2 px-4 py-3 border-b border-[#2A2A25]">
        <span className="w-3 h-3 rounded-full bg-[#FF5F56]" />
        <span className="w-3 h-3 rounded-full bg-[#FFBD2E]" />
        <span className="w-3 h-3 rounded-full bg-[#27C93F]" />
      </div>
      {/* Code content */}
      <div className="p-5 overflow-x-auto">
        <pre className="font-mono text-[13px] leading-relaxed">
          {lines.map((line, i) => renderLine(line, i))}
        </pre>
      </div>
    </div>
  );
}
