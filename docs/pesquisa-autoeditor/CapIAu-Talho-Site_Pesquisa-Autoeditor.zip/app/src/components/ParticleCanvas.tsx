import { useRef, useEffect } from 'react';

interface Particle {
  ox: number;
  oy: number;
  originalOX: number;
  angle: number;
  radius: number;
  speed: number;
  baseSize: number;
  layer: number;
}

export default function ParticleCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let mouseX = -1000;
    let mouseY = -1000;

    const PARTICLE_COUNT = 120;
    const CONNECTION_DISTANCE = 120;
    const MOUSE_RADIUS = 200;
    const FOCAL_LENGTH = 300;
    const BG_COLOR = '#0D0D0C';

    const particles: Particle[] = [];

    function resize() {
      canvas!.width = window.innerWidth;
      canvas!.height = window.innerHeight;
    }

    function initParticles() {
      particles.length = 0;
      const layers = [
        { radiusMin: 80, radiusMax: 150, speedMult: 0.3 },
        { radiusMin: 150, radiusMax: 250, speedMult: 0.5 },
        { radiusMin: 250, radiusMax: 400, speedMult: 0.8 },
      ];

      const perLayer = Math.floor(PARTICLE_COUNT / 3);

      for (let layer = 0; layer < 3; layer++) {
        const config = layers[layer];
        for (let i = 0; i < perLayer; i++) {
          const radius = config.radiusMin + Math.random() * (config.radiusMax - config.radiusMin);
          const angle = Math.random() * Math.PI * 2;
          const speed = (0.002 + Math.random() * 0.003) * config.speedMult * (Math.random() > 0.5 ? 1 : -1);
          const ox = canvas!.width / 2 + (Math.random() - 0.5) * 200;
          const oy = canvas!.height / 2 + (Math.random() - 0.5) * 100;

          particles.push({
            ox,
            oy,
            originalOX: ox,
            angle,
            radius,
            speed,
            baseSize: 1.5 + Math.random() * 2,
            layer,
          });
        }
      }
    }

    function updateParticles() {
      for (const p of particles) {
        p.angle += p.speed;

        // Mouse attraction
        const dx = mouseX - p.ox;
        const dy = mouseY - p.oy;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < MOUSE_RADIUS) {
          p.ox += (mouseX - p.ox) * 0.03;
          p.oy += (mouseY - p.oy) * 0.03;
        } else {
          p.ox += (p.originalOX - p.ox) * 0.01;
          p.oy += (p.oy - p.oy) * 0.01;
        }
      }
    }

    function project(p: Particle) {
      const x = Math.cos(p.angle) * p.radius + p.ox - canvas!.width / 2;
      const y = Math.sin(p.angle) * p.radius * 0.25 + p.oy - canvas!.height / 2;
      const z = Math.sin(p.angle) * p.radius;

      const scale = FOCAL_LENGTH / (FOCAL_LENGTH + z * 500);
      const px = x * scale + canvas!.width / 2;
      const py = y * scale + canvas!.height / 2;
      const size = p.baseSize * scale;

      return { px, py, size, scale };
    }

    function draw() {
      if (!ctx || !canvas) return;

      const scrollY = window.scrollY;
      const fadeOut = Math.max(0, 1 - scrollY / (window.innerHeight * 0.5));
      canvas.style.opacity = String(fadeOut);

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = BG_COLOR;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      updateParticles();

      const projected = particles.map(project);

      // Draw connections
      for (let i = 0; i < projected.length; i++) {
        for (let j = i + 1; j < projected.length; j++) {
          const a = projected[i];
          const b = projected[j];
          const dx = a.px - b.px;
          const dy = a.py - b.py;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < CONNECTION_DISTANCE) {
            const alpha = (1 - dist / CONNECTION_DISTANCE) * 0.12;
            ctx.beginPath();
            ctx.moveTo(a.px, a.py);
            ctx.lineTo(b.px, b.py);
            ctx.strokeStyle = `rgba(232, 93, 62, ${alpha})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }

      // Draw particles
      for (let i = 0; i < projected.length; i++) {
        const p = projected[i];
        const alpha = 0.3 + p.scale * 0.7;

        const safeSize = Math.max(0.1, p.size);
        ctx.beginPath();
        ctx.arc(p.px, p.py, safeSize, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(245, 245, 240, ${alpha})`;
        ctx.shadowBlur = 4;
        ctx.shadowColor = 'rgba(232, 93, 62, 0.3)';
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      animationId = requestAnimationFrame(draw);
    }

    function handleMouseMove(e: MouseEvent) {
      const rect = canvas!.getBoundingClientRect();
      mouseX = e.clientX - rect.left;
      mouseY = e.clientY - rect.top;
    }

    function handleMouseLeave() {
      mouseX = -1000;
      mouseY = -1000;
    }

    resize();
    initParticles();
    draw();

    let resizeTimeout: ReturnType<typeof setTimeout>;
    function handleResize() {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(() => {
        resize();
        initParticles();
      }, 150);
    }

    window.addEventListener('resize', handleResize);
    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        zIndex: 0,
      }}
    />
  );
}
